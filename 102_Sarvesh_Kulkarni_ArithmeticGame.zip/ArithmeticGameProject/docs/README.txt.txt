# Arithmetic Game Project

## Instructions

### Prerequisites
- Ensure Java Development Kit (JDK) is installed.

### Setup
1. Download and save the file "ArithmeticGame.java" in the `src` folder.
2. Open a terminal and navigate to the folder containing the source file.

### Compilation
Use the following command to compile:




### Execution
Run the compiled program with:




### Gameplay
- Enter your name when prompted.
- Answer each arithmetic question presented.
- The game will provide immediate feedback and display your final score.

Enjoy playing the Arithmetic Game!
