import java.util.Random;
import java.util.Scanner;

public class ArithmeticGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Get the user's name
        System.out.print("Enter your name: ");
        String userName = scanner.nextLine();

        // Define the number of questions
        int numQuestions = 5;
        int score = 0;

        // Arrays to store questions and answers
        String[] questions = new String[numQuestions];
        int[] answers = new int[numQuestions];

        // Generate random arithmetic problems
        for (int i = 0; i < numQuestions; i++) {
            int num1 = random.nextInt(100) + 1; // Random number between 1 and 100
            int num2 = random.nextInt(100) + 1; // Random number between 1 and 100
            int operation = random.nextInt(4); // Random operation (0-3)

            switch (operation) {
                case 0: // Addition
                    questions[i] = "What is " + num1 + " + " + num2 + "?";
                    answers[i] = num1 + num2;
                    break;
                case 1: // Subtraction
                    questions[i] = "What is " + num1 + " - " + num2 + "?";
                    answers[i] = num1 - num2;
                    break;
                case 2: // Multiplication
                    questions[i] = "What is " + num1 + " * " + num2 + "?";
                    answers[i] = num1 * num2;
                    break;
                case 3: // Division
                    if (num2 == 0) num2 = 1; // Prevent division by zero
                    questions[i] = "What is " + num1 + " / " + num2 + "?";
                    answers[i] = num1 / num2; // Integer division
                    break;
            }
        }

        // Game loop
        System.out.println("\nWelcome, " + userName + " to the Arithmetic Game!");
        System.out.println("You will be asked " + numQuestions + " questions.");
        System.out.println("Try to get as many correct answers as possible.\n");

        for (int i = 0; i < numQuestions; i++) {
            System.out.println(questions[i]);
            System.out.print("Your answer: ");
            int userAnswer = scanner.nextInt();

            if (userAnswer == answers[i]) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Incorrect! The correct answer was: " + answers[i]);
            }
            System.out.println();
        }

        // Final score
        System.out.println("Game Over, " + userName + "!");
        System.out.println("Your final score is: " + score + " out of " + numQuestions);
        scanner.close();
    }
}
